Create Schema IPL

 CREATE TABLE [IPL].[RegisterDetails](
	[UserName] [varchar](25) NOT NULL,
	[Password] [varchar](25) NULL,
 );  
 select * from [IPL].[RegisterDetails]





Create table [IPL].Users_174789
(
UserId int primary key not null,
UserName varchar(20),
Password varchar(20),
FirstName varchar(20),
LastName varchar(20)
)
 select *from  [IPL].Users_174789

Create table [IPL].Roles_174789
(
RoleId int primary key not null,
RoleName varchar(20)
)

Create table [IPL].UserRoles_174789
(
UserId int foreign key references [IPL].Users_174789(UserId),
RoleId int foreign key references [IPL].Roles_174789(RoleId)
)

Create table [IPL].Team_174789
(
TeamId int primary key not null,
Name varchar(30),
HomeGround varchar(30),
Franchise varchar(30),
LogoImage Image
)

Create table  [IPL].Player_174789
(
PlayerId int primary key not null,
TeamId int foreign key references [IPL].Team_174789(TeamId) ,
Name varchar(30),
Age int,
Speciality varchar(30)
)

Create table  [IPL].PlayerPhoto_174789
(
PlayerId int foreign key references  [IPL].Player_174789(PlayerId),
PlayerPhoto image
)

create table  [IPL].Speciality_174789
( 
SpecialityId int not null,
SpecialityDescription varchar(50) null,
)

create table  [IPL].Venue_174789
(
VenueId int primary key not null,
Location varchar(30),
Description varchar(50)
)
select * from Venue_174789

create table  [IPL].Match_1747
(
MatchId int primary key not null,
TeamOneId int ,
 TeamTwoId int , VenueId int , ScheduleId int , PhotoGroupId int
 )



 create table  [IPL].Schedule_1747
 (
 ScheduleId int primary key not null, 
 MatchId int foreign key references  [IPL].Match_1747(MatchId), 
 VenueId int foreign key references  [IPL].Venue_174789(VenueId),
  Date datetime, 
  StartTime time , 
  EndTime time
 )
 ALTER TABLE  [IPL].Match_1747
ADD FOREIGN KEY (TeamOneId) REFERENCES  [IPL].Team_174789(TeamId);
alter table  [IPL].Match_1747
ADD FOREIGN KEY (TeamTwoId) REFERENCES  [IPL].Team_174789(TeamId);

 alter table  [IPL].Match_1747
 ADD FOREIGN KEY (VenueId) REFERENCES  [IPL].Venue_174789(VenueId);
 alter table  [IPL].Match_1747
 ADD FOREIGN KEY (ScheduleId) REFERENCES  [IPL].Schedule_1747(ScheduleId);

 create table  [IPL].MatchPhoto_174789
 (
 MatchPhotoId int primary key,
 MatchId int foreign key References  [IPL].Match_1747(MatchId),
 Photo image
 )

 create table  [IPL].Ticket_174789
 (
 TicketId int primary key,
   MatchId int foreign key References  [IPL].Match_1747(MatchId),
    CategoryId int,
	 Price int
	 )
alter table  [IPL].Ticket_174789
 ADD FOREIGN KEY (CategoryId) REFERENCES  [IPL].TicketCategory_174789(CategoryId);
 
 select * from 	  Ticket_174789

create table  [IPL].TicketCategory_174789
(
 CategoryId int primary key,
  Name varchar(30),
   Description varchar(30)
   ) 

   create table  [IPL].News_174789
   (
   Id int primary key,
   NewsDate datetime,
   MatchId int foreign key references  [IPL].Match_1747(MatchId),
   Description varchar(30),
   MatchPhotoId int foreign key references  [IPL].MatchPhoto_174789(MatchPhotoId)
   )

  create table  [IPL].statistics_174789
  (
  TeamId int foreign key references  [IPL].Team_174789(TeamId),
  Played int,
  Won int,
  Lost int,
  Tied int,
ForAgainst varchar(20), 
 Pts int, 
)

